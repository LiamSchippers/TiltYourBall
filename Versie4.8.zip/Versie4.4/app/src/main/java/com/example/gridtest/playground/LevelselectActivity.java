package com.example.gridtest.playground;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.example.gridtest.R;
import com.example.gridtest.playground.model.Game;

public class LevelselectActivity extends Activity {
    private MediaPlayer clickSound2;
    public static int index;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        clickSound2 = MediaPlayer.create(this,R.raw.switch31);

        //hide title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        //set app to full screen and keep screen on
        getWindow().setFlags(0xFFFFFFF, WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_levelselect);

        Button btnLevel2 = findViewById(R.id.buttonLevel2);
        Button btnLevel3 = findViewById(R.id.buttonLevel3);
        Button btnLevel4 = findViewById(R.id.buttonLevel4);
        Button btnLevel5 = findViewById(R.id.buttonLevel5);

        if (index == 2 || index >= 2) {
            btnLevel2.setEnabled(true);
        }
        if (index == 3 || index >= 3) {
            btnLevel3.setEnabled(true);
        }
        if (index == 4 || index >= 4) {
            btnLevel4.setEnabled(true);
        }
        if (index == 5 || index >= 5) {
            btnLevel5.setEnabled(true);
        }
    }

    public void clickLevel1(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("index", 1);
        clickSound2.start();
        startActivity(intent);
    }

    public void clickLevel2(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("index", 2);
        clickSound2.start();
        startActivity(intent);
    }

    public void clickLevel3(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("index", 3);
        clickSound2.start();
        startActivity(intent);
    }
    public void clickLevel4(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("index", 4);
        clickSound2.start();
        startActivity(intent);
    }
    public void clickLevel5(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("index", 5);
        clickSound2.start();
        startActivity(intent);
    }
}
