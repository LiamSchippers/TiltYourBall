package com.example.gridtest.playground;

import android.app.Activity;
import android.os.Bundle;

import com.example.gridtest.R;

public class SettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

    }
}
