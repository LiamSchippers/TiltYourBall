package com.example.gridtest.playground;


import com.example.gridtest.R;
import com.example.gridtest.playground.Objects.FinishObject;
import com.example.gridtest.playground.Objects.HoleObject;
import com.example.gridtest.playground.Objects.TeleportFromObject;
import com.example.gridtest.playground.Objects.TeleportToObject;
import com.example.gridtest.playground.Objects.WallObject;
import com.example.gridtest.playground.model.Game;
import com.example.gridtest.playground.model.GameBoard;

import java.io.IOException;
import java.io.InputStream;

public class BallGame extends Game{

    private int currentLevel = 1;
    private GameActivity activity;

    public BallGame(GameActivity mainActivity) {
        super(new BallGameBoard());

        this.activity = mainActivity;

    }


    public void startSelectedLevel(int level) {
        // Maak een gameboard aan en verwijder alle objecten
        GameBoard board = getGameBoard();
        board.removeAllObjects();

        String fileContent = "";

        if (level == 1) {
            this.currentLevel = 1;
            InputStream is = this.activity.getBaseContext().getResources().openRawResource(R.raw.level_1);
            try {
                byte[] b = new byte[is.available()];
                is.read(b);
                fileContent = new String(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (level == 2) {
            this.currentLevel = 2;
            InputStream is = this.activity.getBaseContext().getResources().openRawResource(R.raw.level_2);
            try {
                byte[] b = new byte[is.available()];
                is.read(b);
                fileContent = new String(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (level == 3) {
            currentLevel = 3;
            InputStream is = this.activity.getBaseContext().getResources().openRawResource(R.raw.level_3);
            try {
                byte[] b = new byte[is.available()];
                is.read(b);
                fileContent = new String(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (level == 4) {
            currentLevel = 4;
            InputStream is = this.activity.getBaseContext().getResources().openRawResource(R.raw.level_4);
            try {
                byte[] b = new byte[is.available()];
                is.read(b);
                fileContent = new String(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (level == 5) {
            currentLevel = 5;
            InputStream is = this.activity.getBaseContext().getResources().openRawResource(R.raw.level_5);
            try {
                byte[] b = new byte[is.available()];
                is.read(b);
                fileContent = new String(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Split op nieuwe regel
        String[] row = fileContent.split("\n");
        for (int yCO = 0; yCO < row.length; yCO++) {
            String newRow = row[yCO];

            // Split op komma
            String[] objectIndex = newRow.split(",");
            for (int xCO = 0; xCO < objectIndex.length; xCO++) {
                // Checken of het object een muur is
                if (objectIndex[xCO].equals("1")) {
                    board.addGameObject(new WallObject(),xCO,yCO);
                }
                // Checken of het object een gat is
                if (objectIndex[xCO].equals("2")) {
                    board.addGameObject(new HoleObject(),xCO,yCO);
                }
                if (objectIndex[xCO].equals("3")) {
                    board.addGameObject(new FinishObject(),xCO,yCO);
                }
                if (objectIndex[xCO].equals("4")) {
                    board.addGameObject(new TeleportFromObject(),xCO,yCO);
                }
                if (objectIndex[xCO].equals("5")) {
                    board.addGameObject(new TeleportToObject(),xCO,yCO);
                }
            }
        }
    }

    public int getCurrentLevel() {
        return currentLevel;
    }
}
